﻿===================================================================================================
== model：椛暗式
== modeler：椛暗
===================================================================================================
■About this Model

HI！
Thanks for downloading !
Please use this model within the limit of following matters

■Forbidden matters

•Being used to violate public and order or lacking wise and subtle judgment are forbidden
•Commercial use , Political use, Religious use, Used for forbidden works about R-18 or violence.( All forbidden ! )
•Can't be used to contempt the other countries and  Other people
•Some behaviors to confuse the original author and to other stakeholders are forbidden ( such as be used for Television、Animation production company、Magazinee . etc）
•Can't be used to belittle the original author、original Motion 
•Don't deceive the creator of this data（Contains claiming to be the creator of the model）

■About the distribution and remodeling
・　再配布不可<br>
・　商用利用不可<br>
・　改造用パーツとしての利用不可（禁止改模）<br>
・　Do not redistribute. <br>
・　Do not edit.<br>
・　Thank you for your kind understanding.<br>

2016/8/25　公開
■Disclaimer

The producer of this model ( 椛暗 )  shall not be responsible for any damage and loss caused or alleged to be caused by or in connection with using this model.

■Acknowledgments

MikuMikuDance		higuchuu(樋口優) 
PMDEditor	        KyokuhokuP（極北P）
Metasequoia             tetraface Inc.